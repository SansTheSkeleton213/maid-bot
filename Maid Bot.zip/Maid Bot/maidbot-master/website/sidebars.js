module.exports = {
  someSidebar: {
    Documentation: ['introduction', 'commands'],
  },
};
